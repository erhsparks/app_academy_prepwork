class MyHashSet
end
