def benchmark(count = 1, &prc)
end

def race(count = 1, procs)
end

def eval_block(*args, &prc)
end

def factors(num)
end

class Array
  def bubble_sort!
  end

  def bubble_sort(&prc)
  end
end

# You don't **strictly** need to implement this method, but we do suggest it.
def substrings(string)
end

def subwords(word, dictionary)
end

def doubler(array)
end

class Array
  def my_each(&prc)
  end

  def my_map(&prc)
  end

  def my_select(&prc)
  end

  def my_inject(&blk)
  end
end

def concatenate(strings)
end
