class Array
  def my_uniq
  end

  def two_sum
  end

  def my_transpose
  end

  def median
  end
end

class String
  def caesar(shift)
  end
end

class Hash
  def difference(other_hash)
  end
end

class Fixnum
  def stringify(base)
  end
end
